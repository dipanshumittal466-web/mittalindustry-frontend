
# MittalIndustry Frontend (Next.js)

## Environment
Set your backend base URL:
```bash
NEXT_PUBLIC_API_BASE=https://<your-backend-domain>
```

## Render settings
- Root Directory: `frontend`
- Build Command: `npm install && npm run build`
- Start Command: `npm run start`
