export default function Home() {
  return (
    <div>
      <h1>Welcome to Mittal Industry</h1>
      <p>Your trusted Electrical Material Supplier</p>
    </div>
  )
}
