export default function Contact() {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>Call/WhatsApp: 7668420528</p>
    </div>
  )
}
