export default function Home() {
  return (
    <div>
      <h1>🚀 Mittal Industry Website Running Successfully!</h1>
      <p>Deployment test passed ✅</p>
    </div>
  );
}
